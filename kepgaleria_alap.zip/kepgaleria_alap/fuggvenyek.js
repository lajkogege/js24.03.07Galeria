export function htmlOsszeAllit(lista) {
   
}
