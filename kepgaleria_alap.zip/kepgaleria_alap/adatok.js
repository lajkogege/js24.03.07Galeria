export const KEPEK = [
    {
        kep: "kepek/DSC7681.jpeg",
        cim: "Kakasmandiko",
    },
    {
        kep: "kepek/DSC8847.jpeg",
        cim: "Galambvirág",
    },
    {
        kep: "kepek/DSC8888.jpeg",
        cim: "Májvirág",
    },
    {
        kep: "kepek/DSC8912.jpeg",
        cim: "Tavaszi erdő",
    },
    {
        kep: "kepek/DSC8963.jpeg",
        cim: "Csillagvirág",
    },
    {
        kep: "kepek/DSC9135.jpeg",
        cim: "Keltike",
    },
    {
        kep: "kepek/DSC9311.jpeg",
        cim: "Kakasmandiko",
    },
];
